import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email?:string ;
  password?:string;
  cred?:string;
  

  loginUser()
    {
      if(this.email== "admin@gmail.com"  && this.password =="admin")
      {
        console.log("Welcome");
        this.router?.navigateByUrl('/cards') // navigate to url after success
        this.cred = "success";
      }

      else
      {
      this.cred = "fail";
      }
    }

  constructor(private router?: Router){}

  ngOnInit(): void {
  }

}
