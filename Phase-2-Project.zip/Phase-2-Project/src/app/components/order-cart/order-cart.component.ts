import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/shared/api.service';

@Component({
  selector: 'app-order-cart',
  templateUrl: './order-cart.component.html',
  styleUrls: ['./order-cart.component.css']
})
export class OrderCartComponent implements OnInit {
  foodData: any;
 

  fn?:string ;
  pr?:number;
  array =[] as  any; // now we can  push json objects
  total_bill:number=0;
  customer_name:string="";

  constructor( private api : ApiService) {}
  ngOnInit(): void {
    this.getFoodData();
  }

  getFoodData(){
    this.api.getFood().subscribe(res=> { this.foodData= res})
  }


  FoodCart(fname:string,price:number){
   
    this.fn= fname;
    this.pr=price;
    this.array.push({"fname":this.fn, "price":this.pr});

    //  for(let i in this.array)
     this.total_bill+=Number(this.pr);
    }
}
