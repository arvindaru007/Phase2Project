import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CardsComponent } from './components/cards/cards.component';
import { CrudComponent } from './components/crud/crud.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { OrderCartComponent } from './components/order-cart/order-cart.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'cards',component:CardsComponent},
  {path:'crud',component:CrudComponent},
  {path:'home',component:HomeComponent},
  {path:'login',component:LoginComponent},
  {path:'order',component:OrderCartComponent},
  {path:'', redirectTo:'/home', pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
